# UI Project Server


## Overview
Fast, flexible and extensible web-server for Component-Based architecture/applications. Best for local development and quickly provide POC and demo for bussiness. Based on Express web-server.


## How to use
### Install
Install **node** and **npm**.

```
npm i https://gitlab.exadel.com/EDMTP/static-ui-ecosystem.git#ui-project-server/${VERSION} --save-dev
```

Development version available as: https://gitlab.exadel.com/EDMTP/static-ui-ecosystem.git#ui-project-server/develop
 
### Quick Start
1) Create structure:
```
/PROJECT_ROOT
  /server
    /views
      /layouts
      /pages
        demo-page.html
    start.js
```

2) Open ``start.js`` and add next code:
```javascript
var server = require('ui-project-server');
server.start({}); // Config object can be passed as a first argument
```

3) Edit ``package.json``:
```javascript
"scripts": {
  "server": "node server/start.js"
}
```

4) Add "Hello World!" into ``demo-page.html``

5) Start server by command: ``npm run server``

6) Index page will be opened automatically (manually: [http://localhost:3000/](http://localhost:3000/))


### Engine
Project based on ``Express Web Server`` with self middleware. 
Template engine for pages: ``express-dot-engine`` with some modifications.
Default routing based on folder/file structure under ``${PROJECT_ROOT}/server/views/pages/``.
Server supports pages, layouts, partials and reusable components.
//TDB


### Configuration
Configuration object should be passed as a first argument into ``.start()`` function. 
See description and possible options in the source code: https://gitlab.exadel.com/EDMTP/static-ui-ecosystem/blob/ui-project-server/develop/config/default.js 

### File-Folder Based routing
```mermaid
graph TD
ROOT{URL_PATH is empty or '/'?}
404(Render 'server/views/404.html')

ROOT --> |Yes| Redirect_to_defaultPageUrl( Redirect to '/index.html' )
ROOT --> |No| NoEmptyPath{URL_PATH contains '*.html?'}
NoEmptyPath --> |No| IsFolder{Folder 'server/views/pages/URL_PATH/' exists?}
IsFolder --> |No| 404
IsFolder --> |Yes| Redirect_to_defaultPageUrl_underFolder(Redirect to 'URL_PATH/index.html')
NoEmptyPath --> |Yes| Html{HTML File 'server/views/pages/URL_PATH' exists?}
Html --> |Yes| RenderPageHTML(Render it)
Html --> |No| IsIndex{Is request to 'index.html'?}
IsIndex --> |Yes| RenderIndex(Render 'server/views/index.html')
IsIndex --> |No| 404P(Render 'server/views/404.html')
```

### Page
//TDB

### Components
//TDB


### FAQ
//TDB


### Examples
Please review [UI Project Boilerplate](https://gitlab.exadel.com/EDMTP/static-ui-ecosystem/blob/ui-project-boilerplate/develop/) project. It contains some examples.


### Road map
- [x] Prepare initial project
- [x] Integrate proxy for requests
- [ ] Add site generator
- [ ] Add debug info into the sourcecode
- [ ] Update documentation
